import com.cycling74.max.*;
// simulates predator prey interactions for 3 species using lotka voltera //equations:
//new xi = [old xi * sum Aij(1-xj)] * dt + oldxi


public class LV extends MaxObject
{

	private double DELTA_T = 0.5;
	private double alpha = 0.7;
	private double[] species = {0.2, 0.2, 0.2};
	private double[] newSpecies = {0.0, 0.0, 0.0};
	private double[] deltaSpecies = {0.0, 0.0, 0.0};

	private int nSpecies = 3;
//	private double[] matrix = {0.0, 0.0, 0.0};
//	private double[] initMatrix  = {0.5, 0.5, 0.1, -0.5, -0.1, 0.1, alpha, 0.1, 0.1}; 

	private static final String[] INLET_ASSIST = new String[]{
		"inlet 1 help"
	};
	private static final String[] OUTLET_ASSIST = new String[]{
		"outlet 1 help"
	};
	
	public LV(Atom[] args)
	{
		declareInlets(new int[]{DataTypes.ALL, DataTypes.FLOAT});

		declareOutlets(new int[]{DataTypes.FLOAT, DataTypes.FLOAT, DataTypes.FLOAT});
		
		setInletAssist(INLET_ASSIST);
		setOutletAssist(OUTLET_ASSIST);

	}
    
	public void bang()
	{


	newSpecies[0] = species[0] * ( (0.5 * (1.0 - species[0])) + (0.5*(1-species[1])) +   (0.1*(1.0 -species[2])) ) * DELTA_T + species[0];

	newSpecies[1] = species[1] * ( (-0.5 * (1.0 - species[0])) + (-0.1*(1-species[1])) + (0.1*(1.0 -species[2])) ) * DELTA_T + species[1];

	newSpecies[2] = species[2] * ( (alpha * (1.0 - species[0])) + (0.1*(1-species[1])) + (0.1*(1.0 -species[2])) ) * DELTA_T + species[2];


	for (int i=0; i< nSpecies; i++)
		species[i] = newSpecies[i]; 

	outlet(0, species[0]);
	outlet(1, species[1]);
	outlet(2, species[2]);

	}
    
	public void inlet(int i)
	{
	}
    
	public void inlet(float a)
	{
	
		alpha = a;
	
	}
    
    
	public void list(Atom[] list)
	{
	}
    
}







